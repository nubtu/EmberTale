in embertale there are 4 classes- 
1. mage can use spells and the hit command.
2. soldier can use the hit command. starts off with a sword.
3. peasant can use the hit command
4. archer can use the hit command and the shoot command.
move around using n, s, e and w.